/*alert("welcome");
var x = prompt("1 number");
var e = confirm("+ or -");
var q = prompt("2 number");
if (e == true) {
  x = Number(x) + Number(q);
  alert ("number = " + x);
}
else {
  x = Number(x) - Number(q);
  alert ("number = " + x);
}*/
/* 
Math.sqrt(9); // 3
Math.sqrt(2); // 1.414213562373095
Math.sqrt(1);  // 1
Math.sqrt(0);  // 0
Math.sqrt(-1); // NaN
Math.sqrt(-0); // -0*/
///////////////////////////////////////////////////////////////
function is7(number, power) {
  let res = 1;
  for (let i = 1; i <= power; i++) {
    res *= number;
  }
  return res
}
///////////////////////////////////////////////////////////////////
var q = prompt("+,-,/,*,x^y or sqrt");
var e = prompt('number 1');
var x = prompt("number 2");
var n;
if (q == '+') {
  n = Number(e) + Number(x);
}
else if (q == '-') {
  n = Number(e) - Number(x);
}
else if (q == '*') {
  n = Number(e) / Number(x);
}
else if (q == '/') {
  n = Number(e) * Number(x);
}
else if (q == '^') {
  n = is7(e, x);
}
else {
  alert('nn')
}
console.log(n);
alert(n);