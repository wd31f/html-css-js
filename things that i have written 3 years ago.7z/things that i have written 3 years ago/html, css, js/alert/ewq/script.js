//alert("Hello! bye");
/*
name1 = "erw";
console.log(name1)

x1 = 34;
console.log(x1);

name1 = x1;
console.log(name1);
*/
/*
name = "e";
surname = "w";
age = 34;

console.log(name + "\n" + surname + "\nAge: " + age + "\n")

name = "join";
surname = "qw";
age = 21;

console.log(name + " " + surname + "\nAge: " + age)

nn = "█████";
nn1 = "█▒█▒█";
nn2 = "█████";
nn3 = "█";
nn4 = "█████████";
nn5 = "█████";
console.log("  " + nn + "\n" + "  " + nn1 + "\n" + "  " + nn2 + "\n" + "    " + nn3 + "\n" + nn4 + "\n" + nn3 + " " + nn5 + " " + nn3) */
/*
const x = "Da`at";
console.log(x);
x = "Yesod";
console.log(x); */
/*var nb = false;

if (nb == true)
{
  alert("is nb");
}
else {
  alert("not a nb")
}
*/
/*var binann = 7;
var ds = 9;
var lj = "Age of ";
var li = "wonders";
console.log(li + ds)
console.log(lj + li)

console.log(binann + ds) */

/*console.log(225%10);*/
/*var nah = prompt("How old are you?", 199);
alert("Your age is " + nah);*/
//confirm()
//
/*var wee = confirm("")
if(wee == true)
{
  alert("");
}
else
{
  alert("!");
}*/


/*
var x = 22;
x += 7;
x -= 1;
x /= 2;
x *= 5;
x %= 3;
console.log(x); */

/*
var x = 4;
var pre = ++x;
console.log(pre);
var a = 4;
var u = a++;
console.log(u); */
/*alert("");
var x = prompt("");
var face = confirm("");
if (face == true) {
  x++;
}
else {
  x = Number(x) + 2;
}
alert ("" + x + " ")*/
/*var fg = 3;
var ll =0.47;
//var ns = 0
while (fg < 10) {
  fg += ll;
  console.log(fg)
  //ns++
}
//console.log(" " + fg);*/
/*var mm;
var Num = 1;
do {
  mm = Math.floor(Math.random() * 6)+1;
  console.log(" №" + Num + ": " + mm);
  Num++;
} while (mm != 4);*/
/*while(true) {
  alert('S');
}*/
/*var a;
a = confirm("spam?");
if (a == true) {
  while(true) {
    alert('hi');
  }
}
else {
  alert('')
} */

/*for (let i = 0; i < 10; i++) {
  console.log(i)
}*/

var nn = 2;
var re = 1;
var pow = 10;
for (let i = 1; i <= pow; i++) {
  re *= nn
}
alert(re);