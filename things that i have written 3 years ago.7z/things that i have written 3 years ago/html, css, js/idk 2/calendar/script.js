let now = new Date();
let d1 = new Date('December 17, 1999');
let d2 = new Date(544534453535);
let d3 = new Date();
let d4 = new Date(2017, 12, 25, 14, 20);

// alert(d1);
// alert(d2);
// alert(d3);
// alert(d4);

let d5 = new Date();
let myDate = d5.getDate() + ' - ' + (d5.getMonth() +1) + ' - ' + d5.getFullYear() + 'y. ' + d5.getHours() + ':' + d5.getMinutes();
document.body.innerHTML = "Today: <b>" + myDate + "</b><br>";
//alert(d5.getMilliseconds());
let days = new Array (
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
);
let myday = prompt('Type a date  by format: \"yyyy-mm-dd\"');
let dat = new Date(myday);
alert(dat.toLocaleDateString() + ' - is ' + days[dat.getDay()]);
//work = 275000|| ?>275000
function next() {
  let dat = new Date();
  document.body.innerHTML = "<b>" + dat.toLocaleTimeString() + "</b>";
}
setInterval(next, 1000);