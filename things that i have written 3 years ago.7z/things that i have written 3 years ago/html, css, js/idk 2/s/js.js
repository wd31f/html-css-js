function changeInterface() {
  document.body.style.background = my.color.value;
  document.body.style.color = my.text_color.value;
  var elem = document.getElementsByTagName('p');
  for (let i = 0; i < elem.length; i++) {
    elem[i].style.fontSize = my.size.value + 'px';
  }
}
function execute() {
let a = parseFloat(calc.x.value);
let b = parseFloat(calc.y.value);
if (calc.operation.value == "+") {
calc.res.value = a + b;
}

 if (calc.operation.value == "-") {
calc.res.value = a - b;
}

 if (calc.operation.value == "*") {
calc.res.value = a * b;
}

 if (calc.operation.value == "/") {
if (b == 0) {
alert("Error! Div by 0");
}
else {
calc.res.value = a / b;
}
}
}